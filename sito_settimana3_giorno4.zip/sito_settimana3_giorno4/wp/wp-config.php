<?php
/**
 * Il file base di configurazione di WordPress.
 *
 * Questo file viene utilizzato, durante l’installazione, dallo script
 * di creazione di wp-config.php. Non è necessario utilizzarlo solo via web
 * puoi copiare questo file in «wp-config.php» e riempire i valori corretti.
 *
 * Questo file definisce le seguenti configurazioni:
 *
 * * Impostazioni del database
 * * Chiavi segrete
 * * Prefisso della tabella
 * * ABSPATH
 *
 * * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Impostazioni database - È possibile ottenere queste informazioni dal proprio fornitore di hosting ** //
/** Il nome del database di WordPress */
define( 'DB_NAME', 'sito_settimana3_giorno4' );

/** Nome utente del database */
define( 'DB_USER', 'root' );

/** Password del database */
define( 'DB_PASSWORD', '' );

/** Hostname del database */
define( 'DB_HOST', 'localhost' );

/** Charset del Database da utilizzare nella creazione delle tabelle. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Il tipo di collazione del database. Da non modificare se non si ha idea di cosa sia. */
define( 'DB_COLLATE', '' );

/**#@+
 * Chiavi univoche di autenticazione e di sicurezza.
 *
 * Modificarle con frasi univoche differenti!
 * È possibile generare tali chiavi utilizzando {@link https://api.wordpress.org/secret-key/1.1/salt/ servizio di chiavi-segrete di WordPress.org}
 *
 * È possibile cambiare queste chiavi in qualsiasi momento, per invalidare tutti i cookie esistenti.
 * Ciò forzerà tutti gli utenti a effettuare nuovamente l'accesso.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '9-de@O=^K}pT>d%4y{1z,0@jl7a*gX/>Hg]q@XJ<Uv[d~V~&4;4!,*wHwV7A) QD' );
define( 'SECURE_AUTH_KEY',  '| NlbK[u;=#v{+#NuGA ^UatD2{6;hGb%BT_4?Ua.TkPvG2A+CJkrK,0?iEB[:=,' );
define( 'LOGGED_IN_KEY',    'X.^j#(ASMI% cc1kK2r2n9p2iZa$b4QG/(Bk Jlx(Xb{j^aeHs~@P,xts0FhMJhB' );
define( 'NONCE_KEY',        '/5dNl~otZ*G-bAYmuwv1FwGz4-<L+N)1t,!]iyEDZez$;@$l#}<6^<z/93KyMAka' );
define( 'AUTH_SALT',        '[?4dQWV` AX5k634+1Ap{:xq}~>X)kuH5syE:XAWm A{c<lS.Ebq^PM$[8xs%c:E' );
define( 'SECURE_AUTH_SALT', '!2ddRJ:.:{Gn|F.z(l-)l3TRk.[d~-Qk{PYJb0r$U4@3$m,11djPG=J8X2v@HGU!' );
define( 'LOGGED_IN_SALT',   'zBgRIN70O,w;XY;]xrVS/j(+XPKZ/<Fw1|LOzim3S5LC?_{i7#kDc:dRa119W$=T' );
define( 'NONCE_SALT',       '&M0J!.:OD19X)~q[$e?sz4@JU*u3L[59J~Zh#GHV9: 7!yR!F`R`x2[kXsFM#/=k' );

/**#@-*/

/**
 * Prefisso tabella del database WordPress.
 *
 * È possibile avere installazioni multiple su di un unico database
 * fornendo a ciascuna installazione un prefisso univoco. Solo numeri, lettere e trattini bassi!
 */
$table_prefix = 'wp_';

/**
 * Per gli sviluppatori: modalità di debug di WordPress.
 *
 * Modificare questa voce a TRUE per abilitare la visualizzazione degli avvisi durante lo sviluppo
 * È fortemente raccomandato agli svilupaptori di temi e plugin di utilizare
 * WP_DEBUG all’interno dei loro ambienti di sviluppo.
 *
 * Per informazioni sulle altre costanti che possono essere utilizzate per il debug,
 * leggi la documentazione
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Aggiungere qualsiasi valore personalizzato tra questa riga e la riga "Finito, interrompere le modifiche". */



/* Finito, interrompere le modifiche! Buona pubblicazione. */

/** Path assoluto alla directory di WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Imposta le variabili di WordPress ed include i file. */
require_once ABSPATH . 'wp-settings.php';
